# Shop Cart API

## Overview
The Shop Cart API is a RESTful application designed to manage automobile parts and facilitate a shopping cart experience. It allows users to browse, search, and manage automobile parts while providing functionalities to add and remove items from their shopping cart.

## Features
- **Product Management**: Retrieve a list of automobile parts, view details of specific parts, and search for parts based on various criteria.
- **Shopping Cart Management**: Add products to the cart, remove products from the cart, and view the current contents of the cart.
- **Data Source**: Utilizes a JSON file containing automobile parts data.

## Project Structure
```
shop-cart-api
├── src
│   ├── app.js                # Entry point of the application
│   ├── routes
│   │   ├── cart.js           # Routes for shopping cart operations
│   │   └── products.js       # Routes for product management
│   ├── controllers
│   │   ├── cartController.js  # Controller for cart operations
│   │   └── productsController.js # Controller for product operations
│   ├── models
│   │   ├── cart.js           # Cart model
│   │   └── product.js        # Product model
│   ├── data
│   │   └── automobileParts.json # Data source for automobile parts
│   └── utils
│       └── helpers.js        # Utility functions
├── package.json              # NPM configuration file
└── README.md                 # Project documentation
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd shop-cart-api
   ```
3. Install the dependencies:
   ```
   npm install
   ```

## Usage
To start the application, run:
```
npm start
```
The API will be available at `http://localhost:3000`.

## API Endpoints
- **Products**
  - `GET /api/products` - Retrieve all products
  - `GET /api/products/:id` - Retrieve product details by ID
  - `GET /api/products/search` - Search for products

- **Cart**
  - `POST /api/cart` - Add product to cart
  - `DELETE /api/cart/:id` - Remove product from cart
  - `GET /api/cart` - Get current cart contents

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License.