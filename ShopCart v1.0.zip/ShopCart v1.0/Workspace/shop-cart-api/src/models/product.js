const fs = require('fs');
const path = require('path');

class Product {
    constructor(id, name, description, imageUrl, price, manufacturer, modelCompatibility, partNumber, stock, specifications) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.price = price;
        this.manufacturer = manufacturer;
        this.modelCompatibility = modelCompatibility;
        this.partNumber = partNumber;
        this.stock = stock;
        this.specifications = specifications;
    }

    static getAllProducts() {
        const data = fs.readFileSync(path.join(__dirname, '../data/automobileParts.json'));
        const products = JSON.parse(data);
        return products.map(product => new Product(
            product.id,
            product.name,
            product.description,
            product.image_url,
            product.price,
            product.manufacturer,
            product.model_compatibility,
            product.part_number,
            product.stock,
            product.specifications
        ));
    }

    static getProductById(id) {
        const products = this.getAllProducts();
        return products.find(product => product.id === id);
    }

    static searchProducts(query) {
        const products = this.getAllProducts();
        return products.filter(product => 
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.description.toLowerCase().includes(query.toLowerCase())
        );
    }
}

module.exports = Product;