class Cart {
    constructor() {
        this.items = [];
    }

    addProduct(product) {
        const existingProduct = this.items.find(item => item.id === product.id);
        if (existingProduct) {
            existingProduct.quantity += 1;
        } else {
            this.items.push({ ...product, quantity: 1 });
        }
    }

    removeProduct(productId) {
        this.items = this.items.filter(item => item.id !== productId);
    }

    getCartTotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getCartItems() {
        return this.items;
    }

    clearCart() {
        this.items = [];
    }
}

export default Cart;