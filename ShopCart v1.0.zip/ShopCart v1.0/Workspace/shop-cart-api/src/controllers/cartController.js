class CartController {
    constructor() {
        this.cart = [];
    }

    addProduct(product) {
        const existingProduct = this.cart.find(item => item.id === product.id);
        if (existingProduct) {
            existingProduct.quantity += 1;
        } else {
            this.cart.push({ ...product, quantity: 1 });
        }
    }

    removeProduct(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getCartItems() {
        return this.cart;
    }
}

module.exports = CartController;