class ProductsController {
    constructor(products) {
        this.products = products;
    }

    getAllProducts(req, res) {
        res.json(this.products);
    }

    getProductById(req, res) {
        const productId = parseInt(req.params.id);
        const product = this.products.find(p => p.id === productId);
        if (product) {
            res.json(product);
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    }

    searchProducts(req, res) {
        const { query } = req.query;
        const filteredProducts = this.products.filter(product => 
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.description.toLowerCase().includes(query.toLowerCase())
        );
        res.json(filteredProducts);
    }
}

module.exports = ProductsController;