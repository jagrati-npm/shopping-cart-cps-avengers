const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const ProductsController = require('../controllers/productsController');

// Load products from JSON file
const productsData = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/automobileParts.json'), 'utf-8'));
const productsController = new ProductsController(productsData);

router.get('/', productsController.getAllProducts.bind(productsController));
router.get('/search', productsController.searchProducts.bind(productsController));
router.get('/:id', productsController.getProductById.bind(productsController));

module.exports = router;