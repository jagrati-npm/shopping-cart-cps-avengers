const express = require('express');
const router = express.Router();
const CartController = require('../controllers/cartController');

const cartController = new CartController();

router.post('/add', (req, res) => {
    const product = req.body;
    cartController.addProduct(product);
    res.status(201).json({ message: 'Product added to cart', cart: cartController.getCartItems() });
});

router.delete('/remove/:id', (req, res) => {
    const productId = parseInt(req.params.id, 10);
    cartController.removeProduct(productId);
    res.status(200).json({ message: 'Product removed from cart', cart: cartController.getCartItems() });
});

router.get('/', (req, res) => {
    res.status(200).json({ cart: cartController.getCartItems(), total: cartController.getCartTotal() });
});

module.exports = router;